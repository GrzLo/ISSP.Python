def mniejsza (a, b):
    if a == b:
        print("Liczby są równe")
    elif a < b: 
        print("Liczba", a, "jest mniejsza")
    else:
        print("Liczba", b, "jest mniejsza")


mniejsza(155, 41)
